package com.rawsanj.kafka.listener;

import com.fasterxml.jackson.core.JsonParseException;
import com.rawsanj.kafka.domain.Greeting;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.converter.ConversionException;

/**
 * Created by @author Sanjay Rawat on 3/30/17.
 */

@Configuration
public class MessageListener {

    @KafkaListener(topics = "${message.topic.name}", group = "foo", containerFactory = "kafkaListenerContainerFactory")
    public void listenString(String message) {
        System.out.println("Received Messasge in group Foo: " + message);
    }

    @KafkaListener(topics = "${greeting.topic.name}", group = "greeting", containerFactory = "greetingKafkaListenerContainerFactory")
    public void listenGreeting(Greeting message) {
        try {
            System.out.println("Received Messasge in group Greeting: " + message);
            System.out.println(message.getName());
        }catch (Exception  e){
            System.out.println("Marr gaya");
        }

    }

}
