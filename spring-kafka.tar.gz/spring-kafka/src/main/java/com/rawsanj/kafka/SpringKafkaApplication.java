package com.rawsanj.kafka;

import com.rawsanj.kafka.domain.Greeting;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.core.KafkaTemplate;

import java.util.Date;

@SpringBootApplication
public class SpringKafkaApplication implements CommandLineRunner {

	@Value("${message.topic.name}")
	private String topic;

	@Value("${greeting.topic.name}")
	private String greetingTopic;

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	@Autowired
	@Qualifier(value = "greetingKafkaTemplate")
	private KafkaTemplate<String, Greeting> greetingKafkaTemplate;

	public static void main(String[] args) {
		SpringApplication.run(SpringKafkaApplication.class, args);
	}

	@Override
	public void run(String... strings) throws Exception {
		System.out.println("Sending Message....");

		kafkaTemplate.send(topic,"Hello from Java @"+ new Date());

		greetingKafkaTemplate.send(greetingTopic, new Greeting("Shukla", "Shukla tu chukla"));
	}
}
