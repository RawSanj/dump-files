package io.github.rawsanj;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPClientConfig;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.io.IOException;
import java.util.Arrays;

@SpringBootApplication
public class SpringBootFtpExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFtpExampleApplication.class, args);
	}

	@Bean
	CommandLineRunner commandLineRunner(){
		return strings -> {
			System.out.println("App Started...!");

			FTPClient ftp = new FTPClient();
			FTPClientConfig config = new FTPClientConfig();

			ftp.configure(config);

			try {
				String server = "localhost";
				ftp.connect(server);

				System.out.println("Connected to " + server + ".");
				System.out.print(ftp.getReplyString());

				Arrays.asList(ftp.listFiles()).forEach(f-> {
					System.out.println(f.getName());
				});

				//\\LIN13001755\dumps
				//\\LIN13001856\ToSanjay

//				String myNetworkPath = "\\\\LIN13001856\\ToSanjay";
//				String darshitNwPath = "\\\\LIN13001755\\dumps";
//				try (Stream<Path> stream = Files.list(Paths.get(myNetworkPath))) {
//					String joined = stream
//							.map(String::valueOf)
//							.filter(path -> !path.startsWith("."))
//							.sorted()
//							.collect(Collectors.joining(";\n"));
//					System.out.println("List: " + joined);
//				}
//
//				// After connection attempt, you should check the reply code to verify
//				// success.
//				reply = ftp.getReplyCode();
//
//				if(!FTPReply.isPositiveCompletion(reply)) {
//					ftp.disconnect();
//					System.err.println("FTP server refused connection.");
//					System.exit(1);
//				}
//				System.out.println(ftp.getLocalAddress());
//				System.out.println();
//
//				//... transfer files
				ftp.logout();
			} catch(IOException e) {
				e.printStackTrace();
			} finally {
				if(ftp.isConnected()) {
					try {
						ftp.disconnect();
					} catch(IOException ioe) {
						// do nothing
					}
				}
			}


		};
	}
}
