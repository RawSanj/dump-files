package io.github.rawsanj.autoconfigure.ftp;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Created by Sanjay on 5/13/2017.
 */

@ConfigurationProperties(prefix = "spring.ftp")
public class FtpServerProperties {

    private String serverName;

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }
}
