package io.github.rawsanj.autoconfigure.ftp;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.ftpserver.FtpServer;
import org.apache.ftpserver.FtpServerFactory;
import org.apache.ftpserver.ftplet.FtpException;
import org.apache.ftpserver.listener.ListenerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

/**
 * Created by Sanjay on 5/13/2017.
 */

@Configuration
@EnableConfigurationProperties(FtpServerProperties.class)
public class FTPAutoConfiguration {


    protected static class FtpServerConfig{

    }

    @ConditionalOnProperty(prefix = "spring.ftp", name = "serverName", havingValue = "local")
    protected static class StartLocalFTPServer{

        @Bean
        ListenerFactory listenerFactory(){
            ListenerFactory listenerFactory = new ListenerFactory();
            listenerFactory.setPort(2221);
            return listenerFactory;
        }

        @Bean
        FtpServerFactory ftpServerFactory(ListenerFactory listenerFactory){
            FtpServerFactory ftpServerFactory = new FtpServerFactory();
            ftpServerFactory.addListener("default", listenerFactory.createListener());
            return ftpServerFactory;
        }

        @Bean
        FtpServer ftpServer(FtpServerFactory ftpServerFactory){
            return ftpServerFactory.createServer();
        }

        @Autowired
        FtpServer ftpServer;

        @PostConstruct
        public void startServer(){

            System.out.println("Starting Local FTP Server.... YOLO!");

            try {
                ftpServer.start();

                System.out.println("Is Server Stopped? "+ftpServer.isStopped());

            } catch (FtpException e) {
                e.printStackTrace();
            }
        }


    }

}
