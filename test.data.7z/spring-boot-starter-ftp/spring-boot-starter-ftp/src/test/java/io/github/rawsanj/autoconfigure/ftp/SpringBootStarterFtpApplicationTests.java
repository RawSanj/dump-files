package io.github.rawsanj.autoconfigure.ftp;

import org.junit.Test;

public class SpringBootStarterFtpApplicationTests {

	@Test
	public void contextLoads() {
	}

}
