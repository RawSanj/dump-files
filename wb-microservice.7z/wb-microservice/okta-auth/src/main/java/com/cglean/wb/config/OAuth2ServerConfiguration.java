package com.cglean.wb.config;

//import org.apache.http.client.HttpClient;
//import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
//import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
//import org.apache.http.impl.client.HttpClients;
//import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Map;


@Configuration
public class OAuth2ServerConfiguration {

    @Configuration
    @EnableResourceServer
    protected static class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {
        @Override
        public void configure(HttpSecurity http) throws Exception {
            http.authorizeRequests()
                    .antMatchers("/public/**").permitAll()
                    .antMatchers("/**").authenticated()
                    .and()
                    .csrf().disable();
        }

        @Override
        public void configure(ResourceServerSecurityConfigurer config) {
            config.tokenServices(tokenServices());
        }

        @Bean
        @Primary
        public DefaultTokenServices tokenServices() {
            DefaultTokenServices defaultTokenServices = new DefaultTokenServices();
            defaultTokenServices.setTokenStore(tokenStore());
            return defaultTokenServices;
        }

        @Bean
        public TokenStore tokenStore() {
            return new JwtTokenStore(accessTokenConverter());
        }

        @Bean
        public JwtAccessTokenConverter accessTokenConverter() {
            JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
            Resource resource = new ClassPathResource("okta-auth-server-public.cert");
            String publicKey = null;
            try {
                publicKey = new String(FileCopyUtils.copyToByteArray(resource.getInputStream()));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            converter.setVerifierKey(publicKey);


            return converter;
        }



    }
//
//    private static class CustomJwtAccessTokenConverter extends JwtAccessTokenConverter{
//        @Override
//        protected Map<String, Object> decode(String token) {
//            try {
//                Jwt jwt = JwtHelper.decodeAndVerify(token, verifier);
//                String content = jwt.getClaims();
//                Map<String, Object> map = objectMapper.parseMap(content);
//                if (map.containsKey(EXP) && map.get(EXP) instanceof Integer) {
//                    Integer intValue = (Integer) map.get(EXP);
//                    map.put(EXP, new Long(intValue));
//                }
//                return map;
//            }
//            catch (Exception e) {
//                throw new InvalidTokenException("Cannot convert access token to JSON", e);
//            }
//        }
//
//        //        @Override
////        protected Map<String, Object> decode(String token) {
////            return super.decode(token);
////        }
//    }

//    @Value("classpath:oktaKeystore.jks")
//    private Resource cert;

    @Bean
    RestTemplate getRestTemplate(){
//        SSLConnectionSocketFactory socketFactory = null;
//        File keyStoreFile = null;
//        try {
//            keyStoreFile = cert.getFile();
//
//            System.out.println("**********************************************");
//            System.out.println(keyStoreFile.getAbsolutePath());
//            System.out.println("**********************************************");
//
//            socketFactory = new SSLConnectionSocketFactory(new SSLContextBuilder().loadTrustMaterial(keyStoreFile, "changeit".toCharArray(), new TrustSelfSignedStrategy()).build());
//        } catch (NoSuchAlgorithmException | KeyManagementException | KeyStoreException | IOException | CertificateException e) {
//            e.printStackTrace();
//        }
//        HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();
//        HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
//
//        return new RestTemplate(httpComponentsClientHttpRequestFactory);
        return new RestTemplate();
    }

}