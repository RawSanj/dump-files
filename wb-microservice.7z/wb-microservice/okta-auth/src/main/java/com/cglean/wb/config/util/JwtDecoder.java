package com.cglean.wb.config.util;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.RSAPublicKeySpec;

import org.apache.commons.codec.binary.Base64;

/**
 * Created by Sanjay on 2/17/2017.
 */
public class JwtDecoder {

    // Sample id_token that needs validation. This is probably the only field you need to change to test your id_token.
    // If it doesn't work, try making sure the MODULUS and EXPONENT constants are what you're using, as detailed below.
    public static final String id_token = "eyJhbGciOiJSUzI1NiIsImtpZCI6IlRqMlpqU3pNRWZyamFoSGdCYnJFOGhiNG9pVzQ4Skw2bWQ0RlhLVEhGMU0ifQ.eyJ2ZXIiOjEsImp0aSI6IkFULmt1MUZSSVhnWnlMcEMtc3RNbVVIQmw0X0ZzempUd09yQ09XX0VjZmlwcEEiLCJpc3MiOiJodHRwczovL2Rldi0xODI2Mjgub2t0YXByZXZpZXcuY29tL29hdXRoMi9hdXM5andnb2NiYWpEb3lWcTBoNyIsImF1ZCI6Imh0dHA6Ly9sb2NhbGhvc3Q6ODA4MCIsImlhdCI6MTQ4NzI3MjM2OCwiZXhwIjoxNDg3Mjc1OTY4LCJjaWQiOiJSeTQyM1JXcGh3Q3ZWa3pqekxDbSIsInVpZCI6IjAwdTloazl2ejdqWHY5VE10MGg3Iiwic2NwIjpbIm9wZW5pZCJdLCJzdWIiOiJzYW5qYXkucmF3YXRAY2FwZ2VtaW5pLmNvbSJ9.L2R0gigVoidzW7aXJREKXGOrLjr0wShJTDMfUgxL5epUosmawqUa8tSD8I4Uba6Ke8twg9dRPc61n33OyyM2WWtUWtZoTcvDtqCYXFsNE6zENZXEsNRQJ8V484q9r8vLb2xmR-Z6v9Ws9mdrzxYanUzFN5Scr5onsjeO-Qe8mXXU_qUoOaEoG-c_QqIHcRa68wylTfd3Gsiqif1n_7TrUIT5SM5ZpCKkAPXVGJ3uWpyOWPY9Vn-YPy9dfCg-2rX7Q32-RAJ9CnNOotXjwDbyZs7pLc0tEy2dEezqqp12OIB5lJS7dfVlbMfOYQ-gLKoE0Ur4YWVLm4WYu7zrRGemJA";
    public static final String[] id_token_parts = id_token.split("\\.");

    // Constants that come from the keys your token was signed with.
    // Correct values can be found from using the "kid" value and looking up the "n (MODULUS)" and "e (EXPONENT)" fields
    // at the following url: https://login.salesforce.com/id/keys
    //     MAJOR NOTE: This url will work for 90% of your use cases, but for the other 10%
    //     you'll need to make sure you get the "kid" value from the instance url that
    //     the api responses from Salesforce suggest for your token, as the kid values *will* be different.
    //     e.g. Some users would need to get their kid values from https://na44.salesforce.com/id/keys for example.
    // The following 2 values are hard coded to work with the "kid=196" key values.
    public static final String MODULUS = "my8rn-JVgZWviLl38kJlbYjOvTGV0uWVACInRHpn-i6xlfZoyI_KwGz8kSoVe8JmfzHhdHFUiCv2hiH9nNMNzQ6MemkqzVb2rnSFiOJ-vhlVlWlCozDyR458SjQBVIH3kujwnbdC0dwcLyVoOLqNj-JfqFS36Z7aUKFGbVEsr_AI5RRsn6nsaQ-sFo3-b6uAVoJMIa47q3jG7MgltNfDgmaaonwUPauXZztKzB1ZwJ3yxaXwDfchS-98kfXgzbIg2dU4OBj85UY0RP3BVBkxpuvW0GaUZvuBxfyH6kMhlhWabIql0rzxGjy0eT-z3EUHNuhizGN9HdqrGWzs1YVEcw";
    public static final String EXPONENT = "AQAB";

    public static final String ID_TOKEN_HEADER = base64UrlDecode(id_token_parts[0]);
    public static final String ID_TOKEN_PAYLOAD = base64UrlDecode(id_token_parts[1]);
    public static final byte[] ID_TOKEN_SIGNATURE = base64UrlDecodeToBytes(id_token_parts[2]);

    public void start()
    {
        dumpJwtInfo();
        validateToken();
    }

    public static String base64UrlDecode(String input)
    {
        byte[] decodedBytes = base64UrlDecodeToBytes(input);
        String result = new String(decodedBytes, StandardCharsets.UTF_8);
        return result;
    }

    public static byte[] base64UrlDecodeToBytes(String input)
    {
        Base64 decoder = new Base64(-1, null, true);
        byte[] decodedBytes = decoder.decode(input);

        return decodedBytes;
    }

    public static void dump(String data)
    {
        System.out.println(data);
    }

    public static void dumpJwtInfo()
    {
        dump(ID_TOKEN_HEADER);
        dump(ID_TOKEN_PAYLOAD);
    }

    public static void validateToken()
    {
        PublicKey publicKey = getPublicKey(MODULUS, EXPONENT);
        byte[] data = (id_token_parts[0] + "." + id_token_parts[1]).getBytes(StandardCharsets.UTF_8);

        try
        {
            boolean isSignatureValid = verifyUsingPublicKey(data, ID_TOKEN_SIGNATURE, publicKey);
            System.out.println("isSignatureValid: " + isSignatureValid);
        }
        catch (GeneralSecurityException e)
        {
            e.printStackTrace();
        }

    }

    public static PublicKey getPublicKey(String MODULUS, String EXPONENT)
    {
        byte[] nb = base64UrlDecodeToBytes(MODULUS);
        byte[] eb = base64UrlDecodeToBytes(EXPONENT);
        BigInteger n = new BigInteger(1, nb);
        BigInteger e = new BigInteger(1, eb);

        RSAPublicKeySpec rsaPublicKeySpec = new RSAPublicKeySpec(n, e);
        try
        {
            PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(rsaPublicKeySpec);

            return publicKey;
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Cant create public key", ex);
        }
    }

    private static boolean verifyUsingPublicKey(byte[] data, byte[] signature, PublicKey pubKey) throws GeneralSecurityException
    {
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initVerify(pubKey);
        sig.update(data);

        return sig.verify(signature);
    }

}
