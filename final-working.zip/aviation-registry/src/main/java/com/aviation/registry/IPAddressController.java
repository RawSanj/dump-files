package com.aviation.registry;

import java.net.InetAddress;


import com.aviation.registry.domain.IPAddress;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IPAddressController {

    private int counter;

    @RequestMapping(value = "/ipaddress", method = RequestMethod.GET)
    public IPAddress ipaddress() throws Exception {
        return new IPAddress(++counter, InetAddress.getLocalHost().getHostAddress());
    }
}