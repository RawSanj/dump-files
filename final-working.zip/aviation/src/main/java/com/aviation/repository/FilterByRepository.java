package com.aviation.repository;

import com.aviation.entity.FilterBy;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;

public interface FilterByRepository extends CrudRepository<FilterBy, Serializable> {

}
