package com.aviation.entity;

public class HistoryTest {
	
	private String atanumber;
	
	private String count;

	public String getAtanumber() {
		return atanumber;
	}

	public void setAtanumber(String atanumber) {
		this.atanumber = atanumber;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}
	

}
