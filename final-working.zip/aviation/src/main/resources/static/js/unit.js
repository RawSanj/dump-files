/*$( document ).ready(function() {
  $('#fleet').keyup(function(){
   var valThis = $(this).val().toLowerCase();
    $('.sort_fleet>option').each(function(){
     var text = $(this).text().toLowerCase();
        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
   });
  });
});
*/

/*$( document ).ready(function() {
	  $('#subFleet').keyup(function(){
	   var valThis = $(this).val().toLowerCase();
	    $('.sort_subFleet>option').each(function(){
	     var text = $(this).text().toLowerCase();
	        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
	   });
	  });
	});


$( document ).ready(function() {
	  $('#tail').keyup(function(){
	   var valThis = $(this).val().toLowerCase();
	    $('.sort_tail>option').each(function(){
	     var text = $(this).text().toLowerCase();
	        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
	   });
	  });
	});


$( document ).ready(function() {
	  $('#cpnNo').keyup(function(){
	   var valThis = $(this).val().toLowerCase();
	    $('.sort_cpnNo>option').each(function(){
	     var text = $(this).text().toLowerCase();
	        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
	   });
	  });
	});


$( document ).ready(function() {
	  $('#mfgNo').keyup(function(){
	   var valThis = $(this).val().toLowerCase();
	    $('.sort_mfgNo>option').each(function(){
	     var text = $(this).text().toLowerCase();
	        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
	   });
	  });
	});


$( document ).ready(function() {
	  $('#ataNo').keyup(function(){
	   var valThis = $(this).val().toLowerCase();
	    $('.sort_ataNo>option').each(function(){
	     var text = $(this).text().toLowerCase();
	        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
	   });
	  });
	});
*/


$( document ).ready(function() {
	  $('#fleet1').keyup(function(){
	   var valThis = $(this).val().toLowerCase();
	    $('.sort_fleet1>option').each(function(){
	     var text = $(this).text().toLowerCase();
	        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
	   });
	  });
	});


	$( document ).ready(function() {
		  $('#subFleet1').keyup(function(){
		   var valThis = $(this).val().toLowerCase();
		    $('.sort_subFleet1>option').each(function(){
		     var text = $(this).text().toLowerCase();
		        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
		   });
		  });
		});


	$( document ).ready(function() {
		  $('#tail1').keyup(function(){
		   var valThis = $(this).val().toLowerCase();
		    $('.sort_tail1>option').each(function(){
		     var text = $(this).text().toLowerCase();
		        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
		   });
		  });
		});


	$( document ).ready(function() {
		  $('#cpnNo1').keyup(function(){
		   var valThis = $(this).val().toLowerCase();
		    $('.sort_cpnNo1>option').each(function(){
		     var text = $(this).text().toLowerCase();
		        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
		   });
		  });
		});


	$( document ).ready(function() {
		  $('#mfgNo1').keyup(function(){
		   var valThis = $(this).val().toLowerCase();
		    $('.sort_mfgNo1>option').each(function(){
		     var text = $(this).text().toLowerCase();
		        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
		   });
		  });
		});


	$( document ).ready(function() {
		  $('#ataNo1').keyup(function(){
		   var valThis = $(this).val().toLowerCase();
		    $('.sort_ataNo1>option').each(function(){
		     var text = $(this).text().toLowerCase();
		        (text.indexOf(valThis) == 0) ? $(this).show() : $(this).hide();            
		   });
		  });
		});




