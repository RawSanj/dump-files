package com.aviation.poc.settings.repository;

import com.aviation.poc.settings.entity.FilterBy;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;


public interface FilterByRepository extends CrudRepository<FilterBy, Serializable> {

}
