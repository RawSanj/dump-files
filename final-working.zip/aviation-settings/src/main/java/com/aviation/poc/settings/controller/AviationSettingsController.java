package com.aviation.poc.settings.controller;


import com.aviation.poc.settings.entity.Filter;
import com.aviation.poc.settings.rest.client.AviationComponentApiClient;
import com.aviation.poc.settings.service.AviationSettingsService;
import com.aviation.poc.settings.vo.ComponentVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;

@RestController
public class AviationSettingsController {

	@Autowired
	private AviationSettingsService  aviationSettingsService;
	@Autowired
	private AviationComponentApiClient componentApiClient;
	@RequestMapping(value="/splashScreen", method= RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public List<Object> getSplashData(@RequestParam String componentType){
		
		return componentApiClient.getSplashScreenData(componentType);
	}
	
	@RequestMapping(value = "/getFilters", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Filter> getFilters() {
		return aviationSettingsService.getFilters();
	}
	
	
	@RequestMapping(value = "/loadComponent", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<ComponentVO> loadComponent(@RequestParam(required = false) String start, @RequestParam(required = false) String end) {
		return componentApiClient.getComponentData(start, end);
	}
	
	
	@RequestMapping(value="/getSplashDate", method= RequestMethod.GET/*, produces=MediaType.APPLICATION_JSON_VALUE*/)
	public String getSplashDate(){
		
		 return componentApiClient.getSplashScreenDate();
	}
	

	
	
	
	@RequestMapping(value="/navigationToRemoval", method= RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public List<Long> navigationToRemoval(@RequestParam String actualData, @RequestParam String dataType){
	
		System.out.println("in avaition setting"+actualData+" data type "+dataType);
		 return componentApiClient.navigationToRemoval(actualData,dataType);
				
				 
		
	}
	@RequestMapping(value = "/saveFilter", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void saveFilter(@RequestBody final Filter filter) throws ParseException {
		System.out.println("in save filter"+filter);
		aviationSettingsService.saveFilter(filter);
	}
	
	@RequestMapping(value = "/updateFilter", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void updateFilter(@RequestBody final Filter filter) throws ParseException {
		System.out.println("in update filter"+filter);
		aviationSettingsService.updateFilter(filter);
	}
	
	/*@RequestMapping(value="/navigationToRemoval/{actualData}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public String navigationToRemoval(@RequestParam String actualData){	//
		System.out.println("in avaition setting"+actualData);
		 //return componentApiClient.navigationToRemoval(actualData,dataType);
		return null;
	}*/
}
