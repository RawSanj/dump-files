package com.aviation.poc.settings.rest.client;

import com.aviation.poc.settings.vo.ComponentVO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient("aviation-component-api")
public interface AviationComponentApiClient {
	
	@RequestMapping(value = "/splashScreen", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Object> getSplashScreenData(@RequestParam("componentType") final String componentType);
	
	@RequestMapping(value = "/loadComponent", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ComponentVO> getComponentData(@RequestParam("start") String startDate, @RequestParam("end") String endDate);
	
	
	@RequestMapping(value = "/getSplashDate", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getSplashScreenDate();
	
	@RequestMapping(value="/navigationToRemoval", method= RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public List<Long> navigationToRemoval(@RequestParam("actualData") String actualData, @RequestParam("dataType") String dataType);

}
