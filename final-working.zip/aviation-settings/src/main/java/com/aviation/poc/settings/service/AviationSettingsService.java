package com.aviation.poc.settings.service;


import com.aviation.poc.settings.entity.Filter;

import java.util.List;

public interface AviationSettingsService {

	List<Filter> getFilters();
	
	public void saveFilter(final Filter filter);
	
	public int updateFilter(Filter filter);
}
