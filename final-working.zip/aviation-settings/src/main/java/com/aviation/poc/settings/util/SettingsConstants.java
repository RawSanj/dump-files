package com.aviation.poc.settings.util;

public class SettingsConstants {

	private SettingsConstants() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static final String DATEFORMATNEW = "yyyy-MM-dd";
	
}
