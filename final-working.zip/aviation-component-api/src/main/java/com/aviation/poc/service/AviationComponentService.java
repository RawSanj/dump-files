package com.aviation.poc.service;

import com.aviation.poc.entity.Component;

import java.util.Date;
import java.util.List;

public interface AviationComponentService {

 List<Object> getRemovedComponents(final Date startDate, final Date endDate, final String componentType);
 
 public List<Component> getComponent(Date fromDate, Date toDate);
 
 public com.aviation.poc.vo.ComponentReport getComponents(List<Long> componentIds, String fromDate);
 
 
 List<Long> getComponentsIdsSplashScreen(final String actualData, final String dataType, final Date startDate, final Date endDate);
 

 
}
