package com.aviation.poc.util;

public class ComponentConstants {

	private ComponentConstants() {
		super();
	}

	public static final String DATEFORMATNEW = "yyyy-MM-dd";
}
