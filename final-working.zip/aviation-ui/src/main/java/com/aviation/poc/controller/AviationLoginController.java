package com.aviation.poc.controller;

import com.aviation.poc.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletResponse;

@Controller
public class AviationLoginController {

	@Autowired
	private LoginService loginService;
		
	@RequestMapping(value="/", method= RequestMethod.GET)
	public String login(){
		return "login";
	}
	
	@RequestMapping(value="/login", method= RequestMethod.POST)
	public String loginView(@RequestParam(required=false, name="username") String username, @RequestParam(required=false, name="password") String password, HttpServletResponse response) {
		boolean loginValidRes =  loginService.validateLogin(username, password);
		if(loginValidRes){
			return "dashboard";
		}else{
			return "login";
		}
		
	}
	@RequestMapping(value="/login/redirect", method= RequestMethod.GET)
	public String redirect(){
		return "login";
	}
	
	
	@RequestMapping("/logout")
	public String logout(){
		return "login";
	}
	
	@RequestMapping(value="/home", method= RequestMethod.GET)
	public String home(){
		
		return "dashboard";
	}
	
}
