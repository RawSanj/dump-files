package com.aviation.poc.service;

public interface LoginService {

	boolean validateLogin(final String username, final String password);
}
